from django.shortcuts import redirect,render
from libraryapp.models import book
from libraryapp.forms import AddBookForm , UpdateBookForm , UserRegistrationForm
from django.contrib.auth.decorators import login_required

@login_required
def book_list_view(request):
    data = book.objects.all()
    return render(request,"libraryapp/list.html",{'data':data})

@login_required
def book_detail_view(request,id):
    obj = book.objects.get(pk = id)
    return render(request,"libraryapp/detail.html",{'obj':obj})

@login_required
def book_delete_view(request,id):
    obj = book.objects.get(pk = id)
    if request.method == 'POST':
        obj.delete()
        return redirect("/book/list/")
    return render(request,"libraryapp/delete.html",{'obj':obj})

@login_required
def book_add_view(request):
    form = AddBookForm()
    if request.method == 'POST':
        form = AddBookForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/book/list/')
    return render(request,"libraryapp/add.html",{'form':form})

@login_required
def book_update_view(request,id):
    obj=book.objects.get(pk=id)
    form=UpdateBookForm(instance=obj)
    if request.method=='POST':
        form=UpdateBookForm(request.POST,request.FILES,instance=obj)
        if form.is_valid():
            form.save()
            return redirect(f"/book/detail/{obj.id}/")
    return render(request,"libraryapp/update.html",{'form':form}) 

def user_registration_view(request):
    form = UserRegistrationForm()
    if request.method == "POST":
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request,"libraryapp/register.html",{'form':form})




